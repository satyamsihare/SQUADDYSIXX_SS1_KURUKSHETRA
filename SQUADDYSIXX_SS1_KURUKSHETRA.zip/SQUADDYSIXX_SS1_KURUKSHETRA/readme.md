
##How to Start

cd Backend

npm install

#3start mysql server

##change database username and password in Backend/config/config.js file


node bin/www  or npm start



cd ..
cd Frontend

python start.py

then go!!!!!